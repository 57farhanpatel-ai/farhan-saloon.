# FARHAN SALOON — Premium Unisex Hair, Aesthetic & Grooming Atelier

A modern, responsive, and luxury unisex salon website built with **React 19**, **TypeScript**, **Vite**, **Tailwind CSS**, **TanStack Router**, and **Firebase Firestore** with zero-configuration demo data fallback.

---

## 🌟 Key Highlights & Features

- **Multi-Page Architecture (TanStack Router)**:
  - **Home**: Cinematic hero showcase, operating hours strip, KPI achievements, curated popular services, salon distinction pillars, and featured welcome privilege.
  - **About**: Brand ethos, sanitation and hygiene standards, Master Creative Team bios with specialties and experience, and 3-step consultation ritual.
  - **Services**: 24+ comprehensive unisex hair, barbering, balayage, and spa treatments with live search, category tabs, gender focus filters, and direct booking triggers.
  - **Pricing**: Transparent tier comparison cards (Essential, Signature, VIP Imperial), full itemized service matrix table with stylist vs director rates, and booking FAQ accordion.
  - **Gallery**: High-end visual portfolio with technique notes, master stylist attribution, and interactive detail view.
  - **Offers**: Curated seasonal packages, 1-click clipboard promo code copier with toast feedback, and claim buttons.
  - **Contact**: Live appointment reservation form, concierge general inquiry, interactive showroom locator, operating schedule, and amenity indicators.
- **Appointment Reservation System**:
  - Modal booking flow reachable anywhere across the application (Navbar CTA, service cards, offer cards, and Contact page).
  - Pre-fills requested service and preferred stylist.
  - Auto-generates reference numbers (`ENQ-XXXXXX`).
  - Stores directly into Firebase Firestore or gracefully falls back to browser `localStorage` in offline/demo mode.
- **Aesthetic Excellence (Universal Frontend Design)**:
  - Deep obsidian and velvet plum palette paired with warm champagne gold accents.
  - Resilient vector artwork engine (`SalonArtwork`) preventing broken images.
  - Strict Top Bar Contract with mobile drawer navigation.
  - Accessible typography pairings using **Playfair Display** (editorial serif) and **Plus Jakarta Sans** (clean geometric sans).

---

## 📁 Modular Project Structure

```
├── .env.example                     # Environment variable blueprint
├── firestore.rules                  # Firestore security rules
├── index.html                       # HTML entry point with fonts & metadata
├── package.json                     # Dependencies & scripts
├── README.md                        # Documentation & setup guides
├── tsconfig.json                    # TypeScript compiler configuration
├── vercel.json                      # Vercel SPA rewrite deployment configuration
├── vite.config.ts                   # Vite + Tailwind + React configuration
└── src/
    ├── main.tsx                     # React application bootstrap
    ├── App.tsx                      # Root App entry with RouterProvider
    ├── router.tsx                   # TanStack Router route tree definition
    ├── index.css                    # Tailwind CSS v4 directives & theme styles
    ├── types/
    │   └── index.ts                 # Shared TypeScript models (Services, Stylists, etc.)
    ├── data/
    │   └── salonData.ts             # Rich salon services, pricing, stylists, and FAQ data
    ├── services/
    │   ├── firebase.ts              # Firebase app & Firestore initialization
    │   └── appointmentService.ts    # Service layer with Firestore + demo fallback
    ├── context/
    │   └── BookingContext.tsx       # Global booking modal state provider
    ├── components/
    │   ├── layout/
    │   │   ├── Navbar.tsx           # 3-zone Top Bar Contract with mobile drawer
    │   │   └── Footer.tsx           # Atelier hours, contact details, and site links
    │   ├── common/
    │   │   └── SalonArtwork.tsx     # Resilient luxury editorial artwork component
    │   └── booking/
    │       └── AppointmentModal.tsx # Interactive reservation modal
    └── pages/
        ├── HomePage.tsx             # Home landing page
        ├── AboutPage.tsx            # About & Master team page
        ├── ServicesPage.tsx         # Filterable services menu
        ├── PricingPage.tsx          # Tiers, price matrix & FAQs
        ├── GalleryPage.tsx          # Visual transformations portfolio
        ├── OffersPage.tsx           # Privileges & promo codes
        └── ContactPage.tsx          # Concierge & appointment reservations
```

---

## 🚀 Local Development Setup

To run this project on your local machine after downloading:

### 1. Prerequisites
- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher

### 2. Installation
Open your terminal in the extracted project directory and run:

```bash
npm install
```

### 3. Start Development Server
```bash
npm run dev
```

Visit `http://localhost:3000` in your browser. The application will start immediately in **Demo Mode** with mock data and local storage persistence.

---

## 🔥 Firebase Setup Instructions

The website works immediately out of the box without Firebase. If you wish to connect your own live Firebase Firestore database:

1. Go to the [Firebase Console](https://console.firebase.google.com/) and create a new project.
2. In your Firebase project, navigate to **Firestore Database** and click **Create Database** (start in production mode).
3. Under **Project Settings** > **General**, scroll to **Your apps** and click the **Web** icon (`</>`) to register a web application.
4. Copy the generated configuration values into a local `.env.local` file:

```env
VITE_FIREBASE_API_KEY="your-api-key"
VITE_FIREBASE_AUTH_DOMAIN="your-project-id.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="your-project-id"
VITE_FIREBASE_STORAGE_BUCKET="your-project-id.appspot.com"
VITE_FIREBASE_MESSAGING_SENDER_ID="your-sender-id"
VITE_FIREBASE_APP_ID="your-app-id"
```

5. Deploy or copy the security rules from `firestore.rules` into your Firebase Console under **Firestore Database** > **Rules** tab.
6. Restart your dev server (`npm run dev`). Appointment enquiries and contact messages will now automatically sync directly to your live Firestore collections (`appointment_enquiries` and `contact_messages`).

---

## ☁️ Deployment Instructions

### Deploying to Vercel
This repository is pre-configured with `vercel.json` for client-side routing with TanStack Router:

1. Push your code to a GitHub repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of Farhan Saloon website"
   git branch -M main
   git remote add origin https://github.com/your-username/farhan-saloon.git
   git push -u origin main
   ```
2. Go to [Vercel](https://vercel.com/) and click **Add New Project**.
3. Import your `farhan-saloon` GitHub repository.
4. In the build settings:
   - **Framework Preset**: `Vite`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
5. (Optional) Add your Firebase environment variables under **Environment Variables** in Vercel if using live Firebase.
6. Click **Deploy**. Your salon website will be live with full URL routing support!

---

## 📄 License
SPDX-License-Identifier: Apache-2.0
