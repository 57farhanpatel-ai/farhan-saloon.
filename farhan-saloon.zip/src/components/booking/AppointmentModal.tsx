import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, User, Phone, Mail, Scissors, CheckCircle2, Sparkles, AlertCircle } from 'lucide-react';
import { SALON_SERVICES, SALON_STYLISTS } from '../../data/salonData';
import { submitAppointmentEnquiry, BookingResult } from '../../services/appointmentService';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialServiceId?: string;
  initialStylistId?: string;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  initialServiceId,
  initialStylistId,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [serviceId, setServiceId] = useState(initialServiceId || SALON_SERVICES[0].id);
  const [stylistId, setStylistId] = useState(initialStylistId || '');
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTimeSlot, setPreferredTimeSlot] = useState<'morning' | 'afternoon' | 'evening'>('afternoon');
  const [notes, setNotes] = useState('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionResult, setSubmissionResult] = useState<BookingResult | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Sync if initial props change
  useEffect(() => {
    if (initialServiceId) setServiceId(initialServiceId);
    if (initialStylistId) setStylistId(initialStylistId);
  }, [initialServiceId, initialStylistId]);

  // Set default date to tomorrow
  useEffect(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    setPreferredDate(tomorrow.toISOString().split('T')[0]);
  }, []);

  if (!isOpen) return null;

  const selectedService = SALON_SERVICES.find((s) => s.id === serviceId) || SALON_SERVICES[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!fullName.trim() || !email.trim() || !phone.trim() || !preferredDate) {
      setErrorMsg('Please complete all essential fields (Name, Email, Phone, and Preferred Date).');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await submitAppointmentEnquiry({
        fullName,
        email,
        phone,
        serviceId,
        serviceName: selectedService.name,
        stylistId: stylistId || undefined,
        preferredDate,
        preferredTimeSlot,
        notes,
      });
      setSubmissionResult(res);
    } catch (err: any) {
      setErrorMsg('Could not submit enquiry. Please verify details and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSubmissionResult(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={handleReset}
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-2xl bg-[#130f1d] border border-amber-400/20 rounded-2xl shadow-2xl overflow-hidden z-10 text-neutral-200 my-8">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/10 bg-[#181324]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-400/30 flex items-center justify-center text-amber-400">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-lg font-bold text-white tracking-wide">
                FARHAN SALOON RESERVATION
              </h3>
              <p className="text-xs text-neutral-400">
                Bespoke Unisex Hair & Grooming Consultation
              </p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submissionResult ? (
          /* Confirmation Success State */
          <div className="p-8 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div className="space-y-2">
              <h4 className="font-serif text-2xl font-bold text-white">
                Enquiry Reserved
              </h4>
              <p className="text-sm text-neutral-300 max-w-md mx-auto">
                {submissionResult.message}
              </p>
            </div>

            <div className="p-4 bg-white/[0.03] border border-white/10 rounded-xl max-w-md mx-auto text-left space-y-2 text-xs">
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-neutral-400">Confirmation ID</span>
                <span className="font-mono font-bold text-amber-400">{submissionResult.id}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-neutral-400">Guest Name</span>
                <span className="text-white font-medium">{fullName}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-neutral-400">Service</span>
                <span className="text-white font-medium">{selectedService.name}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-neutral-400">Estimated Price</span>
                <span className="text-amber-300 font-bold">${selectedService.price}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Schedule Window</span>
                <span className="text-white font-medium capitalize">{preferredDate} ({preferredTimeSlot})</span>
              </div>
            </div>

            <p className="text-xs text-neutral-400 italic">
              Our salon concierge will contact you via phone/SMS shortly to lock in your dedicated station time.
            </p>

            <button
              onClick={handleReset}
              className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold text-sm hover:from-amber-400 hover:to-amber-500 transition-all shadow-lg shadow-amber-900/30"
            >
              Done & Return to Salon
            </button>
          </div>
        ) : (
          /* Booking Form */
          <form onSubmit={handleSubmit} className="p-6 space-y-5">
            {errorMsg && (
              <div className="flex items-center gap-2 p-3 text-xs text-rose-300 bg-rose-950/40 border border-rose-800/50 rounded-lg">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Full Name *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-neutral-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    required
                    placeholder="Farhan Patel"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-[#1b1526] border border-white/10 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400/60"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Phone Number *
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="tel"
                    required
                    placeholder="+1 (555) 000-0000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-[#1b1526] border border-white/10 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400/60"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Email Address *
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3 pointer-events-none" />
                <input
                  type="email"
                  required
                  placeholder="your.email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#1b1526] border border-white/10 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400/60"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Select Service *
                </label>
                <select
                  value={serviceId}
                  onChange={(e) => setServiceId(e.target.value)}
                  className="w-full bg-[#1b1526] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400/60"
                >
                  {SALON_SERVICES.map((s) => (
                    <option key={s.id} value={s.id} className="bg-[#181324] text-white">
                      {s.name} (${s.price} · {s.durationMinutes}m)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Preferred Master Stylist
                </label>
                <select
                  value={stylistId}
                  onChange={(e) => setStylistId(e.target.value)}
                  className="w-full bg-[#1b1526] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400/60"
                >
                  <option value="" className="bg-[#181324] text-white">
                    First Available Master Stylist
                  </option>
                  {SALON_STYLISTS.map((st) => (
                    <option key={st.id} value={st.id} className="bg-[#181324] text-white">
                      {st.name} ({st.role})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Preferred Date *
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-neutral-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="date"
                    required
                    value={preferredDate}
                    min={new Date().toISOString().split('T')[0]}
                    onChange={(e) => setPreferredDate(e.target.value)}
                    className="w-full bg-[#1b1526] border border-white/10 rounded-lg pl-9 pr-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400/60"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Preferred Time Window *
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['morning', 'afternoon', 'evening'] as const).map((slot) => (
                    <button
                      type="button"
                      key={slot}
                      onClick={() => setPreferredTimeSlot(slot)}
                      className={`py-2 text-xs font-medium rounded-lg capitalize border transition-colors ${
                        preferredTimeSlot === slot
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                          : 'bg-[#1b1526] border-white/10 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Special Requests / Hair History Notes (Optional)
              </label>
              <textarea
                rows={2}
                placeholder="Mention any chemical history, sensitivity, allergies, or specific reference look..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-[#1b1526] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400/60 resize-none"
              />
            </div>

            {/* Price Preview Banner */}
            <div className="p-3 bg-amber-500/[0.07] border border-amber-500/20 rounded-xl flex items-center justify-between text-xs">
              <div>
                <span className="text-amber-200/90 font-medium">Selected: </span>
                <span className="text-white font-semibold">{selectedService.name}</span>
                <span className="text-neutral-400 ml-1">({selectedService.durationMinutes} min)</span>
              </div>
              <div className="text-right">
                <span className="text-amber-400 font-bold text-sm font-mono">${selectedService.price}</span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={handleReset}
                className="px-4 py-2 text-xs font-medium text-neutral-400 hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold text-xs tracking-wider uppercase hover:from-amber-400 hover:to-amber-500 transition-all shadow-lg shadow-amber-900/30 flex items-center gap-1.5 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Securing Chair...</span>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Confirm Enquiry</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
