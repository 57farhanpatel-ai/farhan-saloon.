import React from 'react';
import { Scissors, Sparkles, Droplets, Heart, Flame, Flower2, Crown, ShieldCheck } from 'lucide-react';

interface SalonArtworkProps {
  type: 'styling' | 'barber' | 'color' | 'spa' | 'treatment' | 'bridal' | 'hero' | 'interior';
  title?: string;
  className?: string;
  aspect?: '16:9' | '4:3' | '1:1' | '3:4';
  src?: string;
}

export const SalonArtwork: React.FC<SalonArtworkProps> = ({
  type,
  title,
  className = '',
  aspect = '4:3',
  src,
}) => {
  const [imageError, setImageError] = React.useState(false);

  const aspectClass = {
    '16:9': 'aspect-[16/9]',
    '4:3': 'aspect-[4/3]',
    '1:1': 'aspect-square',
    '3:4': 'aspect-[3/4]',
  }[aspect];

  // Specific color harmonies and icons for each salon category
  const themeConfig = {
    hero: {
      gradient: 'from-[#2a1b18] via-[#16121f] to-[#0d0a14]',
      glow: 'bg-amber-500/15',
      accentColor: '#e6a74c',
      icon: Scissors,
      label: 'FARHAN SALOON ATELIER',
      tag: 'Couture Unisex Aesthetics',
    },
    styling: {
      gradient: 'from-[#2e1d28] via-[#1c1524] to-[#0f0c16]',
      glow: 'bg-rose-500/15',
      accentColor: '#e879a9',
      icon: Scissors,
      label: 'PRECISION CUTTING & SILK FINISH',
      tag: 'Bespoke Silhouette',
    },
    barber: {
      gradient: 'from-[#172221] via-[#11191c] to-[#0a1012]',
      glow: 'bg-emerald-500/15',
      accentColor: '#4ade80',
      icon: ShieldCheck,
      label: 'GENTLEMAN’S GROOMING SUITE',
      tag: 'Hot Towel & Razor Artistry',
    },
    color: {
      gradient: 'from-[#331c26] via-[#211424] to-[#0e0915]',
      glow: 'bg-amber-400/20',
      accentColor: '#f59e0b',
      icon: Flame,
      label: 'BALAYAGE & VIVID PIGMENTS',
      tag: 'Dimensional Highlights',
    },
    spa: {
      gradient: 'from-[#1a262c] via-[#121c21] to-[#0b1014]',
      glow: 'bg-cyan-500/15',
      accentColor: '#38bdf8',
      icon: Flower2,
      label: 'HYDRA-INFUSION & BOTANICALS',
      tag: 'Cellular Skin Rejuvenation',
    },
    treatment: {
      gradient: 'from-[#221c33] via-[#171324] to-[#0c0915]',
      glow: 'bg-purple-500/15',
      accentColor: '#c084fc',
      icon: Droplets,
      label: 'JAPANESE HEAD SPA & KERATIN',
      tag: 'Trichology Scalp Therapy',
    },
    bridal: {
      gradient: 'from-[#382622] via-[#24171d] to-[#120a10]',
      glow: 'bg-amber-300/20',
      accentColor: '#fbbf24',
      icon: Crown,
      label: 'ROYAL BRIDAL & OCCASIONS',
      tag: 'Haute Couture Metamorphosis',
    },
    interior: {
      gradient: 'from-[#281e18] via-[#1a1421] to-[#0c0a12]',
      glow: 'bg-amber-500/10',
      accentColor: '#d4902f',
      icon: Sparkles,
      label: 'FLAGSHIP SANCTUARY',
      tag: 'Architectural Lounge',
    },
  }[type];

  const IconComponent = themeConfig.icon;

  if (src && !imageError) {
    return (
      <div className={`relative overflow-hidden w-full ${aspectClass} ${className} bg-[#161220]`}>
        <img
          src={src}
          alt={title || themeConfig.label}
          referrerPolicy="no-referrer"
          onError={() => setImageError(true)}
          className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent pointer-events-none" />
      </div>
    );
  }

  return (
    <div
      className={`relative overflow-hidden w-full ${aspectClass} ${className} bg-gradient-to-br ${themeConfig.gradient} border border-white/5 flex flex-col justify-between p-6 select-none group`}
    >
      {/* Background ambient lighting orbs */}
      <div
        className={`absolute -top-12 -right-12 w-48 h-48 rounded-full ${themeConfig.glow} blur-3xl pointer-events-none group-hover:scale-125 transition-transform duration-700`}
      />
      <div
        className="absolute -bottom-16 -left-16 w-56 h-56 rounded-full bg-amber-500/10 blur-3xl pointer-events-none"
      />

      {/* Decorative fine architectural geometric rings */}
      <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
        <div className="w-40 h-40 rounded-full border border-white/40 animate-pulse duration-1000" />
        <div className="absolute w-60 h-60 rounded-full border border-dashed border-white/20" />
      </div>

      {/* Top Header Tag */}
      <div className="relative z-10 flex items-center justify-between">
        <span className="text-[11px] font-medium tracking-widest uppercase text-amber-200/70">
          {themeConfig.label}
        </span>
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center border border-white/10 bg-white/5 backdrop-blur-sm"
          style={{ color: themeConfig.accentColor }}
        >
          <IconComponent className="w-4 h-4" />
        </div>
      </div>

      {/* Centerpiece Monogram & Visual Essence */}
      <div className="relative z-10 my-auto flex flex-col items-center text-center px-4 py-2">
        <div className="relative mb-2">
          <div className="w-14 h-14 rounded-2xl bg-white/[0.04] border border-amber-400/20 flex items-center justify-center backdrop-blur-md shadow-2xl group-hover:border-amber-400/50 transition-colors duration-500">
            <span className="font-serif text-2xl font-bold tracking-wider gold-gradient-text">
              FS
            </span>
          </div>
        </div>
        {title && (
          <h4 className="font-serif text-lg font-medium text-white/95 line-clamp-1 group-hover:text-amber-200 transition-colors">
            {title}
          </h4>
        )}
        <p className="text-xs text-neutral-400 tracking-wide mt-1">
          {themeConfig.tag}
        </p>
      </div>

      {/* Bottom Editorial Bar */}
      <div className="relative z-10 flex items-center justify-between pt-3 border-t border-white/10 text-[11px] text-neutral-400">
        <span className="font-mono text-amber-300/80">Farhan Saloon Unisex</span>
        <span className="flex items-center gap-1 text-white/70">
          <Sparkles className="w-3 h-3 text-amber-400" />
          Master Certified
        </span>
      </div>
    </div>
  );
};
