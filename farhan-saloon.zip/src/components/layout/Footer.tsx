import React from 'react';
import { Link } from '@tanstack/react-router';
import { Scissors, MapPin, Phone, Mail, Clock, ArrowUpRight } from 'lucide-react';
import { SALON_INFO } from '../../data/salonData';
import { useBookingModal } from '../../context/BookingContext';

interface FooterProps {
  onOpenBooking?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking }) => {
  const bookingModal = useBookingModal();
  const handleOpenBooking = onOpenBooking || (() => bookingModal.openBooking());

  return (
    <footer className="w-full bg-[#08060c] border-t border-white/10 text-neutral-300">
      {/* Top Banner Invite */}
      <div className="border-b border-white/[0.06] bg-gradient-to-r from-amber-500/10 via-purple-500/5 to-transparent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h3 className="font-serif text-2xl font-bold text-white tracking-wide">
              Elevate Your Everyday Aesthetic
            </h3>
            <p className="text-sm text-neutral-400">
              Unisex master hair design, razor barbering, and revitalizing skin rituals.
            </p>
          </div>
          <button
            onClick={handleOpenBooking}
            className="px-6 py-3 rounded-lg bg-gradient-to-r from-amber-400 to-amber-600 text-black font-semibold text-xs tracking-wider uppercase hover:from-amber-300 hover:to-amber-500 transition-all shadow-lg shadow-amber-950/40 whitespace-nowrap"
          >
            Reserve Your Chair
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand Column */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center text-black font-serif font-bold text-sm">
                FS
              </span>
              <span className="font-serif text-lg font-bold tracking-widest text-white uppercase">
                FARHAN SALOON
              </span>
            </div>
            <p className="text-sm text-neutral-400 leading-relaxed">
              A bespoke unisex salon dedicated to precision cutting, tailored color chemistries, and therapeutic scalp wellness. Designed for all individuals who value exceptional grooming.
            </p>
            <div className="pt-2 text-xs text-amber-300/80 font-mono">
              Unisex Hair · Barbering · Esthetics · Spa
            </div>
          </div>

          {/* Navigation Links */}
          <div className="space-y-4">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-amber-200/90 font-mono">
              Atelier Pages
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/" className="text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5">
                  Home Sanctuary
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5">
                  About Our Ethos
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5">
                  Service Menu
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5">
                  Pricing Tiers & Inclusions
                </Link>
              </li>
              <li>
                <Link to="/gallery" className="text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5">
                  Visual Transformations
                </Link>
              </li>
              <li>
                <Link to="/offers" className="text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5">
                  Salon Privileges & Offers
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5">
                  Location & Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Operating Hours */}
          <div className="space-y-4">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-amber-200/90 font-mono">
              Salon Hours
            </h4>
            <div className="space-y-3 text-sm">
              {SALON_INFO.hours.map((h, idx) => (
                <div key={idx} className="border-b border-white/5 pb-2">
                  <div className="text-neutral-300 font-medium">{h.days}</div>
                  <div className="text-neutral-400 text-xs mt-0.5 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>{h.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Location & Inquiries */}
          <div className="space-y-4">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-amber-200/90 font-mono">
              Concierge Desk
            </h4>
            <ul className="space-y-3 text-sm text-neutral-400">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{SALON_INFO.address}, {SALON_INFO.city}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{SALON_INFO.phone}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{SALON_INFO.email}</span>
              </li>
            </ul>
            <div className="pt-2">
              <Link
                to="/contact"
                className="inline-flex items-center gap-1 text-xs text-amber-400 hover:text-amber-300 font-medium"
              >
                <span>View Flagship Map & Directions</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <p>© {new Date().getFullYear()} FARHAN SALOON. All rights reserved. Master Unisex Beauty & Grooming.</p>
          <div className="flex items-center gap-6">
            <span>Clean Beauty Commitment</span>
            <span aria-hidden="true">·</span>
            <span>Unisex Hospitality</span>
            <span aria-hidden="true">·</span>
            <span>Eco-Friendly Formulations</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
