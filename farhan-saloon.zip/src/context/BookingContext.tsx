import React, { createContext, useContext, useState } from 'react';
import { AppointmentModal } from '../components/booking/AppointmentModal';

interface BookingContextType {
  openBooking: (serviceId?: string, stylistId?: string) => void;
  closeBooking: () => void;
}

const BookingContext = createContext<BookingContextType | undefined>(undefined);

export const BookingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedServiceId, setSelectedServiceId] = useState<string | undefined>(undefined);
  const [selectedStylistId, setSelectedStylistId] = useState<string | undefined>(undefined);

  const openBooking = (serviceId?: string, stylistId?: string) => {
    setSelectedServiceId(serviceId);
    setSelectedStylistId(stylistId);
    setIsOpen(true);
  };

  const closeBooking = () => {
    setIsOpen(false);
  };

  return (
    <BookingContext.Provider value={{ openBooking, closeBooking }}>
      {children}
      <AppointmentModal
        isOpen={isOpen}
        onClose={closeBooking}
        initialServiceId={selectedServiceId}
        initialStylistId={selectedStylistId}
      />
    </BookingContext.Provider>
  );
};

export const useBookingModal = () => {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error('useBookingModal must be used within a BookingProvider');
  }
  return context;
};
