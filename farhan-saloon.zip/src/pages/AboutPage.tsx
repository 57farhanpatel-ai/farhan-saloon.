import React from 'react';
import { Scissors, Sparkles, Award, ShieldCheck, HeartHandshake, Coffee, Wind, Droplets } from 'lucide-react';
import { SALON_STYLISTS, SALON_INFO } from '../data/salonData';
import { SalonArtwork } from '../components/common/SalonArtwork';
import { useBookingModal } from '../context/BookingContext';

interface AboutPageProps {
  onOpenBooking?: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onOpenBooking }) => {
  const bookingModal = useBookingModal();
  const handleBooking = onOpenBooking || (() => bookingModal.openBooking());
  return (
    <div className="space-y-24 py-12 pb-24">
      {/* 1. HERO BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Our Ethos & Origin</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white tracking-tight leading-tight text-balance">
            Where Craftsmanship Meets Inclusive Unisex Luxury.
          </h1>
          <p className="text-base sm:text-lg text-neutral-300 leading-relaxed">
            Founded with the belief that exceptional haircare and skin aesthetics transcend rigid boundaries, Farhan Saloon was built as an oasis of bespoke artistry, scientific formulation, and warm hospitality.
          </p>
        </div>
      </section>

      {/* 2. THE PHILOSOPHY SPLIT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 rounded-2xl overflow-hidden border border-amber-400/20 shadow-2xl">
            <SalonArtwork
              type="interior"
              title="THE ATELIER SANCTUARY"
              aspect="4:3"
            />
          </div>

          <div className="lg:col-span-6 space-y-6">
            <h2 className="text-3xl font-serif font-bold text-white tracking-tight">
              A Philosophy of Proportion, Texture & Well-Being
            </h2>
            <p className="text-sm text-neutral-300 leading-relaxed">
              At Farhan Saloon, we reject assembly-line haircutting. Every client who sits in our chairs receives a personalized geometric analysis—evaluating bone structure, natural growth swirls, texture behavior, and lifestyle demands.
            </p>
            <p className="text-sm text-neutral-400 leading-relaxed">
              Whether you seek an executive razor fade, a soft French butterfly cut, sun-bleached balayage, or restorative Japanese scalp therapy, our atelier offers equal mastery across all textures and styles.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10 text-xs text-neutral-300">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Hospital-Grade Sterilization</span>
              </div>
              <div className="flex items-center gap-2">
                <Droplets className="w-4 h-4 text-cyan-400" />
                <span>100% Ammonia-Free Color</span>
              </div>
              <div className="flex items-center gap-2">
                <Coffee className="w-4 h-4 text-amber-400" />
                <span>Artisan Espresso Bar</span>
              </div>
              <div className="flex items-center gap-2">
                <HeartHandshake className="w-4 h-4 text-rose-400" />
                <span>Inclusive Unisex Care</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. MASTER STYLISTS & ARTISTIC DIRECTORS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
            Artisans of the Craft
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white tracking-tight">
            Meet the Master Creative Team
          </h2>
          <p className="text-sm text-neutral-400">
            Dedicated professionals with international academy training and decades of combined salon excellence.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SALON_STYLISTS.map((stylist) => (
            <div
              key={stylist.id}
              className="rounded-2xl bg-[#14101e] border border-white/10 p-6 flex flex-col justify-between hover:border-amber-400/40 transition-colors group shadow-lg"
            >
              <div className="space-y-4">
                {/* Monogram Avatar */}
                <div className="flex items-center justify-between">
                  <div
                    className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${stylist.avatarColor} border border-white/20 flex items-center justify-center text-white font-serif font-bold text-xl shadow-lg`}
                  >
                    {stylist.name.split(' ').map((n) => n[0]).join('')}
                  </div>
                  <span className="text-xs font-mono text-amber-300/80">
                    {stylist.experienceYears}+ Yrs Exp
                  </span>
                </div>

                <div>
                  <h3 className="font-serif text-lg font-bold text-white group-hover:text-amber-200 transition-colors">
                    {stylist.name}
                  </h3>
                  <div className="text-xs text-amber-400 font-medium mt-0.5">
                    {stylist.role}
                  </div>
                </div>

                <div className="p-3 bg-white/[0.03] border border-white/5 rounded-xl text-xs space-y-1">
                  <span className="text-neutral-400 font-medium">Signature Discipline:</span>
                  <p className="text-neutral-200">{stylist.specialty}</p>
                </div>

                <p className="text-xs text-neutral-400 leading-relaxed">
                  {stylist.bio}
                </p>
              </div>

              <div className="pt-6 border-t border-white/10 mt-6">
                <button
                  onClick={handleBooking}
                  className="w-full py-2 rounded-lg bg-white/5 hover:bg-amber-500 hover:text-black text-xs font-semibold text-neutral-200 uppercase tracking-wider transition-all flex items-center justify-center gap-1.5"
                >
                  <Scissors className="w-3.5 h-3.5" />
                  <span>Book with {stylist.name.split(' ')[0]}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. THE CLIENT JOURNEY */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-[#120e1c] border border-white/10 p-8 sm:p-12">
          <div className="max-w-xl mb-12">
            <span className="text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
              The Protocol
            </span>
            <h2 className="text-3xl font-serif font-bold text-white tracking-tight mt-2">
              The 3-Step Farhan Saloon Ritual
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-3">
              <span className="font-serif text-3xl font-bold text-amber-400">01</span>
              <h3 className="font-serif text-lg font-semibold text-white">
                Texture & Face Mapping Dialogue
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Before water touches your hair or shears are drawn, we sit for a bespoke consultation to discuss target look, maintenance habits, and past chemical history.
              </p>
            </div>

            <div className="space-y-3">
              <span className="font-serif text-3xl font-bold text-amber-400">02</span>
              <h3 className="font-serif text-lg font-semibold text-white">
                Artisanal Execution & Organic Treatment
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Precision cutting, hand-painted balayage, or hot towel beard architecture paired with restorative botanical hair washes and steam therapy.
              </p>
            </div>

            <div className="space-y-3">
              <span className="font-serif text-3xl font-bold text-amber-400">03</span>
              <h3 className="font-serif text-lg font-semibold text-white">
                Silk Finish & Home Ritual Education
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                We style your look to camera-ready perfection while giving you exact, straightforward guidance on how to reproduce the look effortlessly at home.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
