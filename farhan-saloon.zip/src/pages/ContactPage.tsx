import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2, Scissors, Sparkles, Navigation, Car, Coffee, Wifi } from 'lucide-react';
import { SALON_INFO, SALON_SERVICES, SALON_STYLISTS } from '../data/salonData';
import { submitAppointmentEnquiry, submitContactMessage, BookingResult } from '../services/appointmentService';

export const ContactPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'appointment' | 'message'>('appointment');

  // Appointment State
  const [aptName, setAptName] = useState('');
  const [aptEmail, setAptEmail] = useState('');
  const [aptPhone, setAptPhone] = useState('');
  const [aptServiceId, setAptServiceId] = useState(SALON_SERVICES[0].id);
  const [aptStylistId, setAptStylistId] = useState('');
  const [aptDate, setAptDate] = useState(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [aptTimeSlot, setAptTimeSlot] = useState<'morning' | 'afternoon' | 'evening'>('afternoon');
  const [aptNotes, setAptNotes] = useState('');
  const [aptSubmitting, setAptSubmitting] = useState(false);
  const [aptResult, setAptResult] = useState<BookingResult | null>(null);

  // Message State
  const [msgName, setMsgName] = useState('');
  const [msgEmail, setMsgEmail] = useState('');
  const [msgPhone, setMsgPhone] = useState('');
  const [msgSubject, setMsgSubject] = useState('');
  const [msgBody, setMsgBody] = useState('');
  const [msgSubmitting, setMsgSubmitting] = useState(false);
  const [msgResult, setMsgResult] = useState<BookingResult | null>(null);

  const handleAppointmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aptName.trim() || !aptEmail.trim() || !aptPhone.trim() || !aptDate) return;

    setAptSubmitting(true);
    const service = SALON_SERVICES.find((s) => s.id === aptServiceId) || SALON_SERVICES[0];
    try {
      const res = await submitAppointmentEnquiry({
        fullName: aptName,
        email: aptEmail,
        phone: aptPhone,
        serviceId: aptServiceId,
        serviceName: service.name,
        stylistId: aptStylistId || undefined,
        preferredDate: aptDate,
        preferredTimeSlot: aptTimeSlot,
        notes: aptNotes,
      });
      setAptResult(res);
    } finally {
      setAptSubmitting(false);
    }
  };

  const handleMessageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgName.trim() || !msgEmail.trim() || !msgSubject.trim() || !msgBody.trim()) return;

    setMsgSubmitting(true);
    try {
      const res = await submitContactMessage({
        fullName: msgName,
        email: msgEmail,
        phone: msgPhone || undefined,
        subject: msgSubject,
        message: msgBody,
      });
      setMsgResult(res);
    } finally {
      setMsgSubmitting(false);
    }
  };

  return (
    <div className="space-y-16 py-12 pb-24">
      {/* 1. HEADER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Concierge & Flagship Location</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
            Connect with Farhan Saloon
          </h1>
          <p className="text-base text-neutral-300 leading-relaxed">
            Reserve your styling chair, request bridal wedding trials, or inquire about personalized hair and skin treatments with our guest relations team.
          </p>
        </div>
      </section>

      {/* 2. MAIN FORM & LOCATION SPLIT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Form Column */}
          <div className="lg:col-span-7 rounded-3xl bg-[#14101e] border border-white/10 p-8 shadow-2xl space-y-6">
            {/* Tabs */}
            <div className="flex border-b border-white/10 pb-4 gap-4">
              <button
                onClick={() => setActiveTab('appointment')}
                className={`text-sm font-serif font-medium pb-1 relative transition-colors ${
                  activeTab === 'appointment'
                    ? 'text-amber-300 font-bold'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                Appointment Enquiry
                {activeTab === 'appointment' && (
                  <span className="absolute -bottom-4 left-0 right-0 h-0.5 bg-amber-400" />
                )}
              </button>
              <button
                onClick={() => setActiveTab('message')}
                className={`text-sm font-serif font-medium pb-1 relative transition-colors ${
                  activeTab === 'message'
                    ? 'text-amber-300 font-bold'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                General Inquiry
                {activeTab === 'message' && (
                  <span className="absolute -bottom-4 left-0 right-0 h-0.5 bg-amber-400" />
                )}
              </button>
            </div>

            {activeTab === 'appointment' ? (
              aptResult ? (
                /* Success Screen */
                <div className="py-12 text-center space-y-5">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-9 h-9" />
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-white">
                    Reservation Enquiry Received
                  </h3>
                  <p className="text-sm text-neutral-300 max-w-md mx-auto">
                    {aptResult.message} Reference ID: <strong className="font-mono text-amber-300">{aptResult.id}</strong>
                  </p>
                  <button
                    onClick={() => setAptResult(null)}
                    className="px-6 py-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold uppercase tracking-wider transition-colors"
                  >
                    Submit Another Reservation
                  </button>
                </div>
              ) : (
                /* Appointment Form */
                <form onSubmit={handleAppointmentSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={aptName}
                        onChange={(e) => setAptName(e.target.value)}
                        placeholder="Farhan Patel"
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">
                        Phone *
                      </label>
                      <input
                        type="tel"
                        required
                        value={aptPhone}
                        onChange={(e) => setAptPhone(e.target.value)}
                        placeholder="+1 (555) 000-0000"
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={aptEmail}
                      onChange={(e) => setAptEmail(e.target.value)}
                      placeholder="client@example.com"
                      className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">
                        Service *
                      </label>
                      <select
                        value={aptServiceId}
                        onChange={(e) => setAptServiceId(e.target.value)}
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                      >
                        {SALON_SERVICES.map((s) => (
                          <option key={s.id} value={s.id} className="bg-[#181324] text-white">
                            {s.name} (${s.price})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">
                        Preferred Stylist
                      </label>
                      <select
                        value={aptStylistId}
                        onChange={(e) => setAptStylistId(e.target.value)}
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                      >
                        <option value="" className="bg-[#181324] text-white">Any Available Master Stylist</option>
                        {SALON_STYLISTS.map((st) => (
                          <option key={st.id} value={st.id} className="bg-[#181324] text-white">
                            {st.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">
                        Preferred Date *
                      </label>
                      <input
                        type="date"
                        required
                        value={aptDate}
                        min={new Date().toISOString().split('T')[0]}
                        onChange={(e) => setAptDate(e.target.value)}
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">
                        Time Window *
                      </label>
                      <select
                        value={aptTimeSlot}
                        onChange={(e) => setAptTimeSlot(e.target.value as any)}
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 capitalize"
                      >
                        <option value="morning" className="bg-[#181324] text-white">Morning (9:00 AM – 12:00 PM)</option>
                        <option value="afternoon" className="bg-[#181324] text-white">Afternoon (12:00 PM – 5:00 PM)</option>
                        <option value="evening" className="bg-[#181324] text-white">Evening (5:00 PM – 9:00 PM)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1">
                      Notes or Special Requests
                    </label>
                    <textarea
                      rows={3}
                      value={aptNotes}
                      onChange={(e) => setAptNotes(e.target.value)}
                      placeholder="Hair density, sensitivity, wedding date, or specific questions..."
                      className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={aptSubmitting}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-semibold text-xs tracking-wider uppercase transition-all shadow-lg shadow-amber-950/40 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <Scissors className="w-4 h-4" />
                    <span>{aptSubmitting ? 'Reserving...' : 'Submit Appointment Enquiry'}</span>
                  </button>
                </form>
              )
            ) : (
              msgResult ? (
                /* Message Success */
                <div className="py-12 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-9 h-9" />
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-white">Message Sent</h3>
                  <p className="text-sm text-neutral-300 max-w-md mx-auto">{msgResult.message}</p>
                  <button
                    onClick={() => setMsgResult(null)}
                    className="px-6 py-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold uppercase tracking-wider"
                  >
                    Send Another Inquiry
                  </button>
                </div>
              ) : (
                /* Message Form */
                <form onSubmit={handleMessageSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={msgName}
                        onChange={(e) => setMsgName(e.target.value)}
                        placeholder="Farhan Patel"
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">Phone (Optional)</label>
                      <input
                        type="tel"
                        value={msgPhone}
                        onChange={(e) => setMsgPhone(e.target.value)}
                        placeholder="+1 (555) 000-0000"
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">Email Address *</label>
                      <input
                        type="email"
                        required
                        value={msgEmail}
                        onChange={(e) => setMsgEmail(e.target.value)}
                        placeholder="client@example.com"
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-neutral-300 mb-1">Subject *</label>
                      <input
                        type="text"
                        required
                        value={msgSubject}
                        onChange={(e) => setMsgSubject(e.target.value)}
                        placeholder="Bridal package inquiry, media, etc."
                        className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1">Message *</label>
                    <textarea
                      rows={4}
                      required
                      value={msgBody}
                      onChange={(e) => setMsgBody(e.target.value)}
                      placeholder="How may our concierge team assist you?"
                      className="w-full bg-[#1b1528] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={msgSubmitting}
                    className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold text-xs tracking-wider uppercase transition-all shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                    <span>{msgSubmitting ? 'Sending...' : 'Send Inquiry'}</span>
                  </button>
                </form>
              )
            )}
          </div>

          {/* Location & Details Column */}
          <div className="lg:col-span-5 space-y-6">
            {/* Showroom Contact Card */}
            <div className="rounded-3xl bg-[#14101e] border border-white/10 p-6 space-y-5">
              <h3 className="font-serif text-xl font-bold text-white">
                Flagship Atelier Info
              </h3>

              <div className="space-y-4 text-sm text-neutral-300">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-white font-medium block">Address</span>
                    <span className="text-neutral-400 text-xs">
                      {SALON_INFO.address}, {SALON_INFO.city} {SALON_INFO.postalCode}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-white font-medium block">Concierge Telephone</span>
                    <span className="text-neutral-400 text-xs font-mono">{SALON_INFO.phone}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-white font-medium block">Digital Inquiries</span>
                    <span className="text-neutral-400 text-xs">{SALON_INFO.email}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-white font-medium block">Atelier Hours</span>
                    <div className="text-neutral-400 text-xs space-y-1 mt-1">
                      {SALON_INFO.hours.map((h, i) => (
                        <div key={i}>
                          <strong className="text-neutral-300">{h.days}:</strong> {h.time}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Stylized Interactive Map Preview */}
            <div className="rounded-3xl bg-gradient-to-br from-[#1c1428] to-[#100c18] border border-amber-400/20 p-6 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-amber-300 font-semibold flex items-center gap-1.5">
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Flagship Locator</span>
                </span>
                <span className="text-[11px] text-neutral-400">Valet On-Site</span>
              </div>

              {/* Map representation box */}
              <div className="h-44 rounded-xl bg-[#0b0812] border border-white/10 relative overflow-hidden flex flex-col items-center justify-center text-center p-4">
                <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300 mb-2 animate-bounce">
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="font-serif text-sm font-bold text-white">FARHAN SALOON</div>
                <div className="text-xs text-neutral-400">108 The Grand Promenade</div>
                <div className="mt-3 flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] text-neutral-300">Central Metro: 2 min walk</span>
                </div>
              </div>

              {/* Atelier Amenities */}
              <div className="grid grid-cols-3 gap-2 pt-2 text-center text-[11px] text-neutral-300">
                <div className="p-2 rounded-lg bg-white/[0.03] border border-white/5 flex flex-col items-center gap-1">
                  <Car className="w-4 h-4 text-amber-400" />
                  <span>Complimentary Valet</span>
                </div>
                <div className="p-2 rounded-lg bg-white/[0.03] border border-white/5 flex flex-col items-center gap-1">
                  <Coffee className="w-4 h-4 text-amber-400" />
                  <span>Specialty Coffee</span>
                </div>
                <div className="p-2 rounded-lg bg-white/[0.03] border border-white/5 flex flex-col items-center gap-1">
                  <Wifi className="w-4 h-4 text-amber-400" />
                  <span>Ultra-Fast Fiber</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
