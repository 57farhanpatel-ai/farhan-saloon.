import React, { useState } from 'react';
import { Sparkles, X, Scissors, Award, Eye } from 'lucide-react';
import { GALLERY_ITEMS } from '../data/salonData';
import { GalleryItem } from '../types';
import { SalonArtwork } from '../components/common/SalonArtwork';
import { useBookingModal } from '../context/BookingContext';

interface GalleryPageProps {
  onOpenBooking?: () => void;
}

export const GalleryPage: React.FC<GalleryPageProps> = ({ onOpenBooking }) => {
  const bookingModal = useBookingModal();
  const handleBooking = onOpenBooking || (() => bookingModal.openBooking());
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [activeItem, setActiveItem] = useState<GalleryItem | null>(null);

  const filters = [
    { label: 'All Portfolio', value: 'all' },
    { label: 'Men’s Fades & Grooming', value: 'mens-grooming' },
    { label: 'Color & Balayage', value: 'color-balayage' },
    { label: 'Couture Styling', value: 'hair-styling' },
    { label: 'Head Spa & Treatments', value: 'hair-treatments' },
    { label: 'Royal Bridal', value: 'bridal-occasions' },
  ];

  const filteredItems = selectedFilter === 'all'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter((item) => item.category === selectedFilter);

  return (
    <div className="space-y-16 py-12 pb-24">
      {/* 1. HEADER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Salon Transformations</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
            Visual Atelier Gallery
          </h1>
          <p className="text-base text-neutral-300 leading-relaxed">
            Explore authentic craftsmanship executed by Farhan Saloon master stylists. Each look highlights customized texture mapping, precision sectioning, and organic toning.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex flex-wrap gap-2 mt-8">
          {filters.map((f) => (
            <button
              key={f.value}
              onClick={() => setSelectedFilter(f.value)}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors ${
                selectedFilter === f.value
                  ? 'bg-amber-400 text-black font-semibold shadow-md'
                  : 'bg-[#151020] text-neutral-300 hover:text-white border border-white/5'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </section>

      {/* 2. GALLERY GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveItem(item)}
              className="rounded-2xl bg-[#14101e] border border-white/10 overflow-hidden cursor-pointer group hover:border-amber-400/50 transition-all duration-300 shadow-xl flex flex-col justify-between"
            >
              <div className="relative overflow-hidden">
                <SalonArtwork
                  type={item.artworkType}
                  title={item.title}
                  aspect="4:3"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                  <div className="px-3 py-1.5 rounded-lg bg-black/70 border border-white/20 text-white text-xs font-medium flex items-center gap-1.5 backdrop-blur-sm">
                    <Eye className="w-3.5 h-3.5 text-amber-400" />
                    <span>View Details</span>
                  </div>
                </div>
              </div>

              <div className="p-4 space-y-2">
                <div className="text-[11px] font-mono text-amber-300/80 uppercase">
                  {item.category.replace('-', ' ')}
                </div>
                <h3 className="font-serif text-base font-bold text-white group-hover:text-amber-200 transition-colors line-clamp-1">
                  {item.title}
                </h3>
                <p className="text-xs text-neutral-400 line-clamp-2">
                  {item.description}
                </p>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-neutral-400">
                  <span>Stylist:</span>
                  <span className="text-neutral-200 font-medium">{item.stylistName}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. LIGHTBOX DETAIL MODAL */}
      {activeItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-xl bg-[#141020] border border-amber-400/30 rounded-2xl overflow-hidden shadow-2xl p-6 text-white space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-xs font-mono uppercase text-amber-300">
                  {activeItem.category.replace('-', ' ')}
                </span>
                <h3 className="font-serif text-2xl font-bold text-white mt-1">
                  {activeItem.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveItem(null)}
                className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <SalonArtwork
              type={activeItem.artworkType}
              title={activeItem.title}
              aspect="16:9"
              className="rounded-xl"
            />

            <div className="space-y-4 text-xs">
              <div>
                <span className="text-neutral-400 font-medium">Concept & Result:</span>
                <p className="text-neutral-200 mt-1 leading-relaxed text-sm">
                  {activeItem.description}
                </p>
              </div>

              <div className="p-3 bg-white/[0.03] border border-white/10 rounded-xl space-y-1">
                <span className="text-amber-300 font-semibold uppercase tracking-wider font-mono">
                  Execution Technique:
                </span>
                <p className="text-neutral-300">
                  {activeItem.technique}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-white/5 text-neutral-400">
                <div className="flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>Artisan Stylist: <strong className="text-white">{activeItem.stylistName}</strong></span>
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3 border-t border-white/10">
              <button
                onClick={() => setActiveItem(null)}
                className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setActiveItem(null);
                  handleBooking();
                }}
                className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 text-black font-semibold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-amber-900/30"
              >
                <Scissors className="w-3.5 h-3.5" />
                <span>Request Similar Transformation</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
