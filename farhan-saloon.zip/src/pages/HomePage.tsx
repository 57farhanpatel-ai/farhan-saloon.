import React from 'react';
import { Link } from '@tanstack/react-router';
import { Scissors, Sparkles, Clock, ArrowRight, Shield, Award, Droplets, Check, Tag } from 'lucide-react';
import { SALON_SERVICES, SALON_INFO, SALON_OFFERS } from '../data/salonData';
import { SalonArtwork } from '../components/common/SalonArtwork';
import { useBookingModal } from '../context/BookingContext';

interface HomePageProps {
  onOpenBooking?: (serviceId?: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onOpenBooking }) => {
  const bookingModal = useBookingModal();
  const handleBooking = onOpenBooking || ((serviceId?: string) => bookingModal.openBooking(serviceId));
  const popularServices = SALON_SERVICES.filter((s) => s.popular).slice(0, 4);
  const featuredOffer = SALON_OFFERS[0];

  return (
    <div className="space-y-24 pb-20">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-8 md:pt-16 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
            {/* Left Content Column */}
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Modern Unisex Hair & Aesthetic Atelier</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold tracking-tight text-white leading-[1.1] text-balance">
                Precision Artistry for Every Crown.
              </h1>

              <p className="text-base sm:text-lg text-neutral-300 max-w-xl leading-relaxed">
                Step into a sanctuary where master scissors, multidimensional balayage, artisan barbering, and revitalizing scalp rituals converge. Tailored individually for all genders.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => handleBooking()}
                  className="px-7 py-3.5 rounded-lg bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-black font-semibold text-xs tracking-wider uppercase hover:from-amber-300 hover:to-amber-500 transition-all shadow-xl shadow-amber-950/40 flex items-center gap-2"
                >
                  <Scissors className="w-4 h-4" />
                  <span>Reserve Appointment</span>
                </button>
                <Link
                  to="/services"
                  className="px-6 py-3.5 rounded-lg border border-white/20 text-white font-medium text-xs tracking-wider uppercase hover:bg-white/5 hover:border-white/40 transition-colors flex items-center gap-2"
                >
                  <span>Explore Services</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>

              {/* Operating Hours Quick Strip */}
              <div className="pt-6 border-t border-white/10 flex flex-wrap items-center gap-6 text-xs text-neutral-400">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>Open 7 Days a Week</span>
                </div>
                <span className="hidden sm:inline" aria-hidden="true">·</span>
                <span>Mon–Sat until 9:30 PM</span>
                <span className="hidden sm:inline" aria-hidden="true">·</span>
                <span className="text-amber-300/90 font-medium">Flagship Central Promenade</span>
              </div>
            </div>

            {/* Right Hero Visual Column */}
            <div className="lg:col-span-5 relative flex items-center justify-center">
              <div className="w-full relative">
                {/* Decorative glow backing */}
                <div className="absolute -inset-4 bg-gradient-to-r from-amber-500/20 to-purple-600/20 rounded-3xl blur-2xl" />
                <div className="relative rounded-2xl overflow-hidden border border-amber-400/30 shadow-2xl">
                  <SalonArtwork
                    type="hero"
                    title="FARHAN SALOON FLAGSHIP"
                    aspect="4:3"
                    className="w-full h-full min-h-[360px]"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column KPI Strip */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-md">
            {SALON_INFO.stats.map((stat, i) => (
              <div key={i} className="text-center px-2 py-1">
                <div className="font-serif text-2xl sm:text-3xl font-bold text-amber-300 tabular-nums">
                  {stat.value}
                </div>
                <div className="text-xs text-neutral-400 mt-1 uppercase tracking-wider font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 2. SIGNATURE ATELIER SERVICES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono mb-2">
              Curated Offerings
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white tracking-tight">
              Master Unisex Services
            </h2>
          </div>
          <Link
            to="/services"
            className="text-xs font-medium text-amber-400 hover:text-amber-300 uppercase tracking-wider flex items-center gap-1.5"
          >
            <span>Browse Full 24+ Service Catalog</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {popularServices.map((service) => (
            <div
              key={service.id}
              className="rounded-2xl bg-[#14101e] border border-white/10 overflow-hidden flex flex-col justify-between hover:border-amber-400/40 transition-all duration-300 group shadow-lg"
            >
              <div>
                <SalonArtwork
                  type={service.artworkType}
                  title={service.name}
                  aspect="4:3"
                />

                <div className="p-5 space-y-3">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span className="capitalize font-mono text-amber-300/80">
                      {service.target}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-neutral-400" />
                      {service.durationMinutes} min
                    </span>
                  </div>

                  <h3 className="font-serif text-lg font-bold text-white group-hover:text-amber-200 transition-colors line-clamp-1">
                    {service.name}
                  </h3>

                  <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                    {service.description}
                  </p>

                  <div className="pt-2 flex items-baseline gap-2">
                    <span className="text-xl font-bold font-mono text-amber-300">
                      ${service.price}
                    </span>
                    {service.originalPrice && (
                      <span className="text-xs text-neutral-500 line-through font-mono">
                        ${service.originalPrice}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-5 pt-0">
                <button
                  onClick={() => handleBooking(service.id)}
                  className="w-full py-2.5 rounded-lg bg-white/5 border border-white/10 hover:bg-amber-500 hover:border-amber-400 hover:text-black text-white text-xs font-semibold tracking-wider uppercase transition-all flex items-center justify-center gap-2"
                >
                  <Scissors className="w-3.5 h-3.5" />
                  <span>Book This Service</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. THE FARHAN SALOON DISTINCTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-br from-[#1a1326] via-[#120e1c] to-[#0c0914] border border-amber-400/20 p-8 sm:p-12">
          <div className="max-w-2xl mb-12">
            <span className="text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
              The Atelier Standard
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white tracking-tight mt-2">
              Why Discerning Guests Choose Farhan Saloon
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-400/30 flex items-center justify-center text-amber-400">
                <Scissors className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-white">
                Bespoke Consultations
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                We never execute without understanding your daily styling routine, hair density, and facial symmetry.
              </p>
            </div>

            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
                <Droplets className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-white">
                100% Organic Formulations
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Zero ammonia, zero harsh parabens. Exclusively ethical botanical elixirs and Italian micro-pigments.
              </p>
            </div>

            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-400/30 flex items-center justify-center text-purple-400">
                <Shield className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-white">
                Private Styling Pods
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Enjoy acoustic quietude and personal space for sensitive scalp treatments, bridal preparations, or executive privacy.
              </p>
            </div>

            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-400/30 flex items-center justify-center text-rose-400">
                <Award className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-white">
                Master Stylists
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Every team member undergoes continuous European & Japanese academy training in precision techniques.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. FEATURED PROMOTION CALLOUT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-10 rounded-2xl bg-gradient-to-r from-amber-500/15 via-[#1e172a] to-purple-900/20 border border-amber-400/30 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="space-y-3 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-amber-300">
              <Tag className="w-3.5 h-3.5" />
              <span>{featuredOffer.badge}</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white">
              {featuredOffer.title} ({featuredOffer.discount})
            </h3>
            <p className="text-sm text-neutral-300 max-w-xl">
              {featuredOffer.description} Use code <span className="font-mono text-amber-300 font-bold bg-black/40 px-2 py-0.5 rounded">{featuredOffer.code}</span> when booking.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 shrink-0">
            <button
              onClick={() => handleBooking(popularServices[0].id)}
              className="px-6 py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-semibold text-xs uppercase tracking-wider transition-colors shadow-lg"
            >
              Claim This Privilege
            </button>
            <Link
              to="/offers"
              className="px-5 py-3 rounded-lg border border-white/20 text-neutral-300 hover:text-white text-xs uppercase tracking-wider transition-colors"
            >
              View All Offers
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
