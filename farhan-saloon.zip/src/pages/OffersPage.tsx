import React, { useState } from 'react';
import { Tag, Sparkles, Copy, Check, Scissors, Clock, Info } from 'lucide-react';
import { SALON_OFFERS } from '../data/salonData';
import { SalonOffer } from '../types';
import { useBookingModal } from '../context/BookingContext';

interface OffersPageProps {
  onOpenBooking?: () => void;
}

export const OffersPage: React.FC<OffersPageProps> = ({ onOpenBooking }) => {
  const bookingModal = useBookingModal();
  const handleBooking = onOpenBooking || (() => bookingModal.openBooking());
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 3000);
  };

  return (
    <div className="space-y-16 py-12 pb-24">
      {/* 1. HEADER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Salon Privileges & Packages</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
            Curated Privileges & Offers
          </h1>
          <p className="text-base text-neutral-300 leading-relaxed">
            Experience our master styling and spa rituals with limited-time privileges. Copy any code and present it during your appointment consultation or online reservation enquiry.
          </p>
        </div>
      </section>

      {/* 2. OFFERS GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SALON_OFFERS.map((offer) => {
            const isCopied = copiedCode === offer.code;

            return (
              <div
                key={offer.id}
                className="rounded-3xl bg-gradient-to-br from-[#1b1428] via-[#140f20] to-[#0d0915] border border-amber-400/25 p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden group hover:border-amber-400/50 transition-all duration-300"
              >
                {/* Ambient glow in corner */}
                <div className="absolute -top-16 -right-16 w-44 h-44 bg-amber-500/10 rounded-full blur-3xl pointer-events-none group-hover:scale-125 transition-transform" />

                <div className="space-y-6 relative z-10">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full bg-amber-500/15 border border-amber-400/30 text-amber-300 text-xs font-mono font-semibold uppercase">
                      {offer.badge}
                    </span>
                    <span className="text-2xl font-serif font-bold text-amber-300 font-mono">
                      {offer.discount}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-serif text-2xl font-bold text-white group-hover:text-amber-200 transition-colors">
                      {offer.title}
                    </h3>
                    <p className="text-xs text-neutral-300 mt-2 leading-relaxed">
                      {offer.description}
                    </p>
                  </div>

                  {/* Promo Code Box */}
                  <div className="p-4 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-4">
                    <div>
                      <div className="text-[10px] font-mono uppercase tracking-wider text-neutral-400">
                        Privilege Promo Code
                      </div>
                      <div className="font-mono text-lg font-bold text-amber-300 tracking-wider">
                        {offer.code}
                      </div>
                    </div>

                    <button
                      onClick={() => handleCopyCode(offer.code)}
                      className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                        isCopied
                          ? 'bg-emerald-500 text-black'
                          : 'bg-white/10 hover:bg-white/20 text-white'
                      }`}
                    >
                      {isCopied ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Code</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Terms */}
                  <div className="space-y-2 pt-2 border-t border-white/5 text-xs text-neutral-400">
                    <div className="flex items-center gap-1.5 text-neutral-300 font-medium">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>{offer.validUntil}</span>
                    </div>
                    <ul className="space-y-1 pl-1">
                      {offer.terms.map((t, i) => (
                        <li key={i} className="flex items-center gap-1.5">
                          <span className="w-1 h-1 rounded-full bg-neutral-500" />
                          <span>{t}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-8 relative z-10">
                  <button
                    onClick={handleBooking}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-semibold text-xs tracking-wider uppercase transition-all shadow-lg shadow-amber-950/40 flex items-center justify-center gap-2"
                  >
                    <Scissors className="w-3.5 h-3.5" />
                    <span>Claim Offer & Reserve Chair</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. POLICY NOTE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/10 flex items-start gap-4 text-xs text-neutral-400">
          <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            Privilege codes may be mentioned in the notes section of the online enquiry form or spoken directly to your host at arrival. One offer per visit. Cannot be retroactively applied to completed appointments.
          </p>
        </div>
      </section>
    </div>
  );
};
