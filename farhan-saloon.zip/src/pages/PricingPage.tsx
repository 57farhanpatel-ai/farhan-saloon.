import React, { useState } from 'react';
import { Sparkles, Check, ChevronDown, ChevronUp, Scissors, HelpCircle } from 'lucide-react';
import { PRICING_TIERS, FAQ_ITEMS, SALON_SERVICES } from '../data/salonData';
import { useBookingModal } from '../context/BookingContext';

interface PricingPageProps {
  onOpenBooking?: () => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({ onOpenBooking }) => {
  const bookingModal = useBookingModal();
  const handleBooking = onOpenBooking || (() => bookingModal.openBooking());
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  return (
    <div className="space-y-24 py-12 pb-24">
      {/* 1. HEADER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Honest & Transparent Investment</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
            Atelier Pricing Tiers
          </h1>
          <p className="text-base text-neutral-300 leading-relaxed">
            We operate with complete pricing transparency. Every service level includes consultation, wash, premium organic botanicals, and customized finishing. Zero hidden add-on fees.
          </p>
        </div>
      </section>

      {/* 2. 3 TIER CARDS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {PRICING_TIERS.map((tier) => (
            <div
              key={tier.id}
              className={`rounded-3xl p-8 flex flex-col justify-between relative transition-all duration-300 ${
                tier.recommended
                  ? 'bg-gradient-to-b from-[#241a33] to-[#140e21] border-2 border-amber-400/80 shadow-2xl shadow-amber-950/40 lg:-translate-y-2'
                  : 'bg-[#130f1e] border border-white/10 shadow-xl'
              }`}
            >
              {tier.recommended && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-amber-400 to-amber-500 text-black text-[11px] font-bold tracking-widest uppercase shadow-md">
                  Most Celebrated Tier
                </div>
              )}

              <div className="space-y-6">
                <div>
                  <h3 className="font-serif text-2xl font-bold text-white">
                    {tier.name}
                  </h3>
                  <p className="text-xs text-amber-300/80 font-mono mt-1">
                    {tier.subtitle}
                  </p>
                </div>

                <div className="py-2 border-y border-white/10">
                  <div className="text-3xl font-serif font-bold text-white tabular-nums">
                    {tier.priceRange}
                  </div>
                  <div className="text-xs text-neutral-400 mt-0.5">
                    Per bespoke ritual appointment
                  </div>
                </div>

                <p className="text-xs text-neutral-300 leading-relaxed">
                  {tier.description}
                </p>

                <div className="space-y-3 pt-2">
                  <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400 font-mono">
                    Tier Inclusions:
                  </span>
                  <ul className="space-y-2.5">
                    {tier.features.map((feat, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-xs text-neutral-200">
                        <Check className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-8">
                <button
                  onClick={handleBooking}
                  className={`w-full py-3 rounded-xl font-semibold text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-2 ${
                    tier.recommended
                      ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black hover:from-amber-300 hover:to-amber-400 shadow-lg shadow-amber-900/30'
                      : 'bg-white/10 text-white hover:bg-white/20'
                  }`}
                >
                  <Scissors className="w-3.5 h-3.5" />
                  <span>Reserve This Tier</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. TRANSPARENT PRICE SHEET TABLE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-[#120e1c] border border-white/10 p-6 sm:p-10 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
            <div>
              <h2 className="text-2xl font-serif font-bold text-white tracking-tight">
                A La Carte Menu Matrix
              </h2>
              <p className="text-xs text-neutral-400 mt-1">
                Standard vs Creative Director pricing with exact chair durations.
              </p>
            </div>
            <button
              onClick={handleBooking}
              className="px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-semibold text-xs uppercase tracking-wider transition-colors self-start sm:self-auto"
            >
              Book from Menu
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-white/10 text-xs font-mono uppercase text-neutral-400">
                  <th className="py-3 px-4">Service</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Duration</th>
                  <th className="py-3 px-4 text-right">Stylist Rate</th>
                  <th className="py-3 px-4 text-right">Director Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs text-neutral-300">
                {SALON_SERVICES.map((s) => (
                  <tr key={s.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 font-medium text-white">
                      {s.name}
                    </td>
                    <td className="py-3.5 px-4 capitalize text-neutral-400 font-mono">
                      {s.category.replace('-', ' ')}
                    </td>
                    <td className="py-3.5 px-4 tabular-nums text-neutral-400">
                      {s.durationMinutes} min
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-semibold text-amber-300 tabular-nums">
                      ${s.price}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-neutral-400 tabular-nums">
                      ${Math.round(s.price * 1.35)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* 4. FREQUENTLY ASKED QUESTIONS ACCORDION */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-3 mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Salon Policies</span>
          </div>
          <h2 className="text-3xl font-serif font-bold text-white tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-xs text-neutral-400">
            Everything you need to know about our consultations, patch tests, and salon protocols.
          </p>
        </div>

        <div className="space-y-4">
          {FAQ_ITEMS.map((item, index) => {
            const isOpen = openFaq === index;
            return (
              <div
                key={index}
                className="rounded-xl bg-[#14101e] border border-white/10 overflow-hidden transition-colors"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 text-white hover:text-amber-200"
                >
                  <span className="font-serif text-base font-medium">
                    {item.q}
                  </span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-amber-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-neutral-400 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-xs text-neutral-300 leading-relaxed border-t border-white/5 pt-3">
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
