import React, { useState, useMemo } from 'react';
import { Search, Scissors, Clock, Check, Sparkles, Filter } from 'lucide-react';
import { SALON_SERVICES } from '../data/salonData';
import { ServiceCategory, GenderTarget } from '../types';
import { SalonArtwork } from '../components/common/SalonArtwork';
import { useBookingModal } from '../context/BookingContext';

interface ServicesPageProps {
  onOpenBooking?: (serviceId?: string) => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ onOpenBooking }) => {
  const bookingModal = useBookingModal();
  const handleBooking = onOpenBooking || ((serviceId?: string) => bookingModal.openBooking(serviceId));
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTarget, setSelectedTarget] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories: { label: string; value: string }[] = [
    { label: 'All Services', value: 'all' },
    { label: 'Men’s Grooming', value: 'mens-grooming' },
    { label: 'Haute Styling', value: 'hair-styling' },
    { label: 'Color & Balayage', value: 'color-balayage' },
    { label: 'Spa & Skincare', value: 'spa-skincare' },
    { label: 'Hair Treatments', value: 'hair-treatments' },
    { label: 'Bridal & Occasions', value: 'bridal-occasions' },
  ];

  const targets: { label: string; value: string }[] = [
    { label: 'All Genders', value: 'all' },
    { label: 'Unisex', value: 'unisex' },
    { label: 'Men’s', value: 'mens' },
    { label: 'Women’s', value: 'womens' },
  ];

  const filteredServices = useMemo(() => {
    return SALON_SERVICES.filter((s) => {
      const matchesCategory = selectedCategory === 'all' || s.category === selectedCategory;
      const matchesTarget = selectedTarget === 'all' || s.target === selectedTarget;
      const matchesSearch =
        searchQuery === '' ||
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.included.some((inc) => inc.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesTarget && matchesSearch;
    });
  }, [selectedCategory, selectedTarget, searchQuery]);

  return (
    <div className="space-y-16 py-12 pb-24">
      {/* 1. PAGE HEADER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-amber-300 uppercase font-mono">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Full Atelier Service Menu</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
            Curated Services & Treatments
          </h1>
          <p className="text-base text-neutral-300 leading-relaxed">
            Every service at Farhan Saloon is executed with precision, organic certified botanicals, and personalized care. Filter by discipline or search below.
          </p>
        </div>

        {/* 2. SEARCH & FILTER CONTROLS */}
        <div className="mt-10 p-6 rounded-2xl bg-[#130f1e] border border-white/10 space-y-6">
          {/* Search bar */}
          <div className="relative max-w-xl">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3.5 pointer-events-none" />
            <input
              type="text"
              placeholder="Search services (e.g. Balayage, Beard, Keratin, Facial, Head Spa)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#1b1528] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400/60"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-xs text-neutral-400 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="space-y-3">
            <div className="text-xs font-medium text-neutral-400 flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-amber-400" />
              <span>Discipline Filter</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.value}
                  onClick={() => setSelectedCategory(cat.value)}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                    selectedCategory === cat.value
                      ? 'bg-amber-400 text-black font-semibold shadow-md'
                      : 'bg-[#1b1528] text-neutral-300 hover:text-white border border-white/5'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Gender Target Filter */}
          <div className="space-y-2 pt-2 border-t border-white/5">
            <div className="text-xs font-medium text-neutral-400">
              Focus
            </div>
            <div className="flex flex-wrap gap-2">
              {targets.map((tgt) => (
                <button
                  key={tgt.value}
                  onClick={() => setSelectedTarget(tgt.value)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                    selectedTarget === tgt.value
                      ? 'bg-white/20 text-white font-semibold'
                      : 'bg-transparent text-neutral-400 hover:text-white'
                  }`}
                >
                  {tgt.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 3. SERVICE CARDS GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between pb-6 border-b border-white/10 text-xs text-neutral-400">
          <span>Showing <strong className="text-white font-mono">{filteredServices.length}</strong> services</span>
          {(selectedCategory !== 'all' || selectedTarget !== 'all' || searchQuery) && (
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedTarget('all');
                setSearchQuery('');
              }}
              className="text-amber-400 hover:underline"
            >
              Reset all filters
            </button>
          )}
        </div>

        {filteredServices.length === 0 ? (
          <div className="py-20 text-center space-y-4">
            <p className="text-neutral-400 text-sm">
              No salon services matched your query "{searchQuery}".
            </p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedTarget('all');
                setSearchQuery('');
              }}
              className="px-4 py-2 rounded-lg bg-amber-400 text-black font-semibold text-xs uppercase tracking-wider"
            >
              View All Services
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-8">
            {filteredServices.map((service) => (
              <div
                key={service.id}
                className="rounded-2xl bg-[#14101e] border border-white/10 overflow-hidden flex flex-col justify-between hover:border-amber-400/40 transition-all duration-300 shadow-xl group"
              >
                <div>
                  <SalonArtwork
                    type={service.artworkType}
                    title={service.name}
                    aspect="16:9"
                  />

                  <div className="p-6 space-y-4">
                    <div className="flex items-center justify-between text-xs">
                      <span className="capitalize font-mono text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                        {service.target}
                      </span>
                      <span className="flex items-center gap-1 text-neutral-400 font-mono">
                        <Clock className="w-3.5 h-3.5 text-neutral-400" />
                        {service.durationMinutes} mins
                      </span>
                    </div>

                    <div>
                      <h3 className="font-serif text-xl font-bold text-white group-hover:text-amber-200 transition-colors">
                        {service.name}
                      </h3>
                      <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                        {service.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-white/5 space-y-2">
                      <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 font-mono">
                        Included in this ritual:
                      </span>
                      <ul className="space-y-1.5">
                        {service.included.map((inc, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs text-neutral-300">
                            <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                            <span>{inc}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="p-6 pt-0 border-t border-white/5 flex items-center justify-between mt-4">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-neutral-400 font-mono">Price</div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold font-mono text-amber-300">
                        ${service.price}
                      </span>
                      {service.originalPrice && (
                        <span className="text-xs text-neutral-500 line-through font-mono">
                          ${service.originalPrice}
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => handleBooking(service.id)}
                    className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-semibold text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-950/40 flex items-center gap-1.5"
                  >
                    <Scissors className="w-3.5 h-3.5" />
                    <span>Book Service</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
