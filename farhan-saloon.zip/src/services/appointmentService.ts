import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, isFirebaseConfigured } from './firebase';
import { AppointmentEnquiry, ContactEnquiry } from '../types';

const LOCAL_STORAGE_KEY_APPOINTMENTS = 'farhan_salon_appointments_v1';
const LOCAL_STORAGE_KEY_CONTACT = 'farhan_salon_contact_v1';

export interface BookingResult {
  success: boolean;
  id: string;
  isDemoFallback: boolean;
  message: string;
}

/**
 * Submits an appointment enquiry to Firestore or seamlessly falls back to LocalStorage demo store.
 */
export async function submitAppointmentEnquiry(
  payload: Omit<AppointmentEnquiry, 'id' | 'createdAt' | 'status'>
): Promise<BookingResult> {
  const enquiryData: AppointmentEnquiry = {
    ...payload,
    id: 'ENQ-' + Math.floor(100000 + Math.random() * 900000),
    createdAt: new Date().toISOString(),
    status: 'pending',
  };

  // Try Firebase Firestore first if configured
  if (isFirebaseConfigured && db) {
    try {
      const docRef = await addDoc(collection(db, 'appointment_enquiries'), {
        ...payload,
        status: 'pending',
        createdAt: serverTimestamp(),
      });
      return {
        success: true,
        id: docRef.id,
        isDemoFallback: false,
        message: 'Your appointment reservation enquiry has been secured in our salon booking database.',
      };
    } catch (err) {
      console.warn('Firestore write failed, saving to local browser storage fallback:', err);
    }
  }

  // Demo Fallback (LocalStorage)
  try {
    const existingRaw = localStorage.getItem(LOCAL_STORAGE_KEY_APPOINTMENTS);
    const existing: AppointmentEnquiry[] = existingRaw ? JSON.parse(existingRaw) : [];
    existing.unshift(enquiryData);
    localStorage.setItem(LOCAL_STORAGE_KEY_APPOINTMENTS, JSON.stringify(existing));

    return {
      success: true,
      id: enquiryData.id || 'FS-DEMO',
      isDemoFallback: true,
      message: 'Appointment enquiry simulated successfully! Stored locally in demo mode.',
    };
  } catch (err) {
    return {
      success: true,
      id: 'FS-' + Date.now().toString().slice(-6),
      isDemoFallback: true,
      message: 'Appointment enquiry confirmed in instant demo mode.',
    };
  }
}

/**
 * Submits a general contact or styling inquiry
 */
export async function submitContactMessage(
  payload: Omit<ContactEnquiry, 'id' | 'createdAt'>
): Promise<BookingResult> {
  const messageData: ContactEnquiry = {
    ...payload,
    id: 'MSG-' + Math.floor(100000 + Math.random() * 900000),
    createdAt: new Date().toISOString(),
  };

  if (isFirebaseConfigured && db) {
    try {
      const docRef = await addDoc(collection(db, 'contact_messages'), {
        ...payload,
        createdAt: serverTimestamp(),
      });
      return {
        success: true,
        id: docRef.id,
        isDemoFallback: false,
        message: 'Your inquiry has been received by our guest relations team.',
      };
    } catch (err) {
      console.warn('Firestore write failed, falling back to local storage:', err);
    }
  }

  try {
    const existingRaw = localStorage.getItem(LOCAL_STORAGE_KEY_CONTACT);
    const existing: ContactEnquiry[] = existingRaw ? JSON.parse(existingRaw) : [];
    existing.unshift(messageData);
    localStorage.setItem(LOCAL_STORAGE_KEY_CONTACT, JSON.stringify(existing));
  } catch (e) {
    // ignore local storage errors
  }

  return {
    success: true,
    id: messageData.id || 'MSG-DEMO',
    isDemoFallback: true,
    message: 'Your message has been received in demo preview mode.',
  };
}

/**
 * Retrieves past enquiries stored in browser (for user verification during test)
 */
export function getLocalAppointmentEnquiries(): AppointmentEnquiry[] {
  try {
    const existingRaw = localStorage.getItem(LOCAL_STORAGE_KEY_APPOINTMENTS);
    return existingRaw ? JSON.parse(existingRaw) : [];
  } catch {
    return [];
  }
}
