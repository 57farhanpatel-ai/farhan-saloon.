export type ServiceCategory = 
  | 'hair-styling'
  | 'mens-grooming'
  | 'color-balayage'
  | 'spa-skincare'
  | 'hair-treatments'
  | 'bridal-occasions';

export type GenderTarget = 'unisex' | 'mens' | 'womens';

export interface SalonService {
  id: string;
  name: string;
  category: ServiceCategory;
  target: GenderTarget;
  durationMinutes: number;
  price: number;
  originalPrice?: number;
  description: string;
  included: string[];
  popular?: boolean;
  artworkType: 'styling' | 'barber' | 'color' | 'spa' | 'treatment' | 'bridal';
}

export interface Stylist {
  id: string;
  name: string;
  role: string;
  experienceYears: number;
  specialty: string;
  bio: string;
  avatarColor: string;
}

export interface PricingTier {
  id: string;
  name: string;
  subtitle: string;
  priceRange: string;
  description: string;
  features: string[];
  recommended?: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: ServiceCategory;
  artworkType: 'styling' | 'barber' | 'color' | 'spa' | 'treatment' | 'bridal';
  description: string;
  technique: string;
  stylistName: string;
}

export interface SalonOffer {
  id: string;
  code: string;
  title: string;
  discount: string;
  description: string;
  validUntil: string;
  targetServices: string;
  terms: string[];
  badge: string;
  colorTheme: 'gold' | 'rose' | 'plum' | 'emerald';
}

export interface AppointmentEnquiry {
  id?: string;
  fullName: string;
  email: string;
  phone: string;
  serviceId: string;
  serviceName: string;
  stylistId?: string;
  preferredDate: string;
  preferredTimeSlot: 'morning' | 'afternoon' | 'evening';
  notes?: string;
  status: 'pending' | 'confirmed' | 'contacted';
  createdAt: string;
}

export interface ContactEnquiry {
  id?: string;
  fullName: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
  createdAt: string;
}
